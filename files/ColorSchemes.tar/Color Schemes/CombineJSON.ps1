$baseFileName = "combined"
$extension = ".json"
$counter = 1

# Fonction pour obtenir le prochain nom de fichier disponible
function Get-NextAvailableFileName {
    $fileName = "${baseFileName}${extension}"
    while (Test-Path $fileName) {
        $counter++
        $fileName = "${baseFileName}${counter}${extension}"
    }
    return $fileName
}

# Obtenir le prochain nom de fichier disponible
$outputFileName = Get-NextAvailableFileName

# Exécuter la combinaison
Get-ChildItem -Path .\*.json | 
Where-Object { $_.Name -notmatch "^${baseFileName}(\d+)?${extension}$" } |
Get-Content -Raw |
ConvertFrom-Json |
ConvertTo-Json -Depth 100 |
Out-File -FilePath $outputFileName

Write-Host "Les fichiers JSON ont été combinés dans : $outputFileName"